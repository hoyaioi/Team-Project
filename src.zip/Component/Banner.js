import React from "react";
import "../CSS/Banner.css";

const Banner = () => {
  return (
    <div className="banner">
      <div>
        <a href="">배너사진</a>
      </div>
    </div>
  );
};

export default Banner;
