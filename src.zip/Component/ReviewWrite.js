import '../CSS/ReviewWrite.css';

function ReviewWrite() {
    return(
        <>
            <div className="myreviewWriteForm">
                <form>
                    <h3>리뷰작성하기</h3><br/>
                    <input></input>
                    <textarea></textarea>
                    <input type='file'></input>
                    <input></input>
                </form>
            </div>
        </>
    );
}

export default ReviewWrite;